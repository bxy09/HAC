#!/usr/bin/perl -w
#read classInfo
use Data::Dumper;
foreach my $doc_for_each_class(700) {#(50,100,200,300,400) {
	foreach $data_index(1..1) {
		my $temp = &readClassInfo('classInfo',$doc_for_each_class);
		my $doc_num = $temp->{doc_num};
		my %class_info = %{$temp->{class_info}};
		print $doc_num."\n";
		print Dumper(%class_info)."\n";
		my $high_index = 1;
		my $low_index = 1;
		my $doc_index = 0;

		my @sample_ratio = (0.05,0.1,0.15);
		my @sample_for_random_doc_ids;
		my @sample_for_random_doc_labels;
		my @sample_for_even_doc_labels;
		foreach my $ratio(@sample_ratio) {
			my @temp1 = (reverse getRandomVector(0,$doc_num ,int($doc_num*$ratio)));
			my @temp2 = ();
			my @temp3 = ();
			push @sample_for_random_doc_ids, \@temp1;
			push @sample_for_random_doc_labels, \@temp2;
			push @sample_for_even_doc_labels, \@temp3;
		}
		my $data_address = "even_${doc_num}_${data_index}";
		system("rm -rf ${data_address}");
		system("mkdir ${data_address}");
		open DOC_MAT,">${data_address}/doc_mat" or die 'can\'t open doc_mat';
		open LABEL_TOP,">${data_address}/label_top" or die 'can\'t open label_top';
		open LABEL_BOTTOM,">${data_address}/label_bottom" or die 'can\'t open label_bottom';
		foreach my $main_class(sort keys %class_info) {
			#manipulate main class
			my @select_docs;
			if($class_info{$main_class}->{doc_num} <= $doc_for_each_class) {
				@select_docs = reverse (0..($class_info{$main_class}->{doc_num}-1));
			} else {
				@select_docs = reverse getRandomVector(0,($class_info{$main_class}->{doc_num}),$doc_for_each_class);
			}
			open DOC, "<$main_class" or die "can't open $main_class";
			my @sample_for_this_class_in_even =();
			foreach my $ratio(@sample_ratio) {
				my @temp = (reverse getRandomVector($doc_index,$doc_index + scalar @select_docs,int($ratio*scalar @select_docs)));
				push @sample_for_this_class_in_even,
					\@temp;
			}
			my $local_index = 0;
			while(<DOC>){
				last if(scalar @select_docs == 0);
				if($local_index == $select_docs[scalar @select_docs - 1]) {
					pop @select_docs;
					print DOC_MAT $_;
					print LABEL_TOP $high_index."\n";
					print LABEL_BOTTOM $low_index."\n";
					foreach (0.. (scalar @sample_ratio - 1)) {
						if(scalar @{$sample_for_random_doc_ids[$_]} != 0) {
							my $temp_index = pop @{$sample_for_random_doc_ids[$_]};
							if($temp_index == $doc_index) {
								push @{$sample_for_random_doc_labels[$_]},"${doc_index} ${low_index} ${high_index}";
							} else {
								push @{$sample_for_random_doc_ids[$_]},$temp_index;
							}
						}
						if(scalar @{$sample_for_this_class_in_even[$_]} != 0) {
							my $temp_index = pop @{$sample_for_this_class_in_even[$_]};
							if($temp_index == $doc_index) {
								push @{$sample_for_even_doc_labels[$_]},"${doc_index} ${low_index} ${high_index}";
							} else {
								push @{$sample_for_this_class_in_even[$_]},$temp_index;
							}
						}
					}
					$doc_index ++;
					$low_index ++;
				}
				$local_index ++;
			}
			close DOC;
			#manipulate secondary class
			if(!(defined $class_info{$main_class}->{child})) {$high_index++;next;}
			foreach my $secondary_class(sort keys %{$class_info{$main_class}->{child}}) {
				my @select_docs;
				if($class_info{$main_class}->{child}->{$secondary_class}->{doc_num} <= $doc_for_each_class) {
					@select_docs = reverse (0..($class_info{$main_class}->{child}->{$secondary_class}->{doc_num}-1));
				} else {
					@select_docs = reverse getRandomVector(0,
						($class_info{$main_class}->{child}->{$secondary_class}->{doc_num}),$doc_for_each_class);
				}
				open DOC, "<$secondary_class" or die "can't open $main_class";
				@sample_for_this_class_in_even =();
				foreach my $ratio(@sample_ratio) {
					my @temp = (reverse getRandomVector($doc_index,$doc_index + scalar @select_docs,int($ratio*scalar @select_docs)));
					push @sample_for_this_class_in_even,
						\@temp;
				}
				my $local_index = 0;
				while(<DOC>){
					last if(scalar @select_docs == 0);
					if($local_index == $select_docs[scalar @select_docs - 1]) {
						pop @select_docs;
						print DOC_MAT $_;
						print LABEL_TOP $high_index."\n";
						print LABEL_BOTTOM $low_index."\n";
						foreach (0.. (scalar @sample_ratio - 1)) {
							if(scalar @{$sample_for_random_doc_ids[$_]} != 0) {
								my $temp_index = pop @{$sample_for_random_doc_ids[$_]};
								if($temp_index == $doc_index) {
									push @{$sample_for_random_doc_labels[$_]},"${doc_index} ${low_index} ${high_index}";
								} else {
									push @{$sample_for_random_doc_ids[$_]},$temp_index;
								}
							}
							if(scalar @{$sample_for_this_class_in_even[$_]} != 0) {
								my $temp_index = pop @{$sample_for_this_class_in_even[$_]};
								if($temp_index == $doc_index) {
									push @{$sample_for_even_doc_labels[$_]},"${doc_index} ${low_index} ${high_index}";
								} else {
									push @{$sample_for_this_class_in_even[$_]},$temp_index;
								}
							}
						}
						$doc_index ++;
					}
					$local_index ++;
				}
				close DOC;
				$low_index ++;
			}
			$high_index ++;
		}
		close DOC_MAT;
		close LABEL_TOP;
		close LABEL_BOTTOM;
		#todo :get mat
		system("cp $data_address/label_top $data_address/label_middle");
		# print sample
		foreach (0..(scalar @sample_ratio - 1)) {
			my $ratio = $sample_ratio[$_];
			my $random_folder_path = "$data_address/sample_random_${ratio}_1";
			my $even_folder_path = "$data_address/sample_even_${ratio}_1";
			system("rm -rf ${random_folder_path}");
			system("rm -rf ${even_folder_path}");
			system("mkdir ${random_folder_path}");
			system("mkdir ${even_folder_path}");
			open LABEL_MARKED, ">${random_folder_path}/label_marked";
			print LABEL_MARKED "2\n";
			print LABEL_MARKED scalar @{$sample_for_random_doc_labels[$_]}.' '.($low_index - 1).' '.($high_index - 1)."\n";
			print LABEL_MARKED $_."\n" foreach (@{$sample_for_random_doc_labels[$_]});
			close LABEL_MARKED;

			open LABEL_MARKED, ">${even_folder_path}/label_marked";
			print LABEL_MARKED "2\n";
			print LABEL_MARKED scalar @{$sample_for_even_doc_labels[$_]}.' '.($low_index - 1).' '.($high_index - 1)."\n";
			print LABEL_MARKED $_."\n" foreach (@{$sample_for_even_doc_labels[$_]});
			close LABEL_MARKED;
		}
	}
}

sub readClassInfo{
	open CLASS_INFO, "<$_[0]";
	my $doc_for_each_class = $_[1];
	my %main_classes;
	my $total_doc_num = 0;

	my $temp_str = <CLASS_INFO>;
	my ($main_class_num) = $temp_str =~ m{main:(\d+)};
	defined $main_class_num or die 'can\'t parse classInfo';
	foreach(1..$main_class_num) {
		$temp_str = <CLASS_INFO>;
		chomp $temp_str;
		-e $temp_str or die 'don\'t have class file';
		my $temp_doc_num = int(`wc -l <$temp_str`);
		$main_classes{$temp_str} = {doc_num=>$temp_doc_num};
		if($temp_doc_num > $doc_for_each_class) {
			$total_doc_num += $doc_for_each_class;
		} else {
			$total_doc_num += $temp_doc_num
		}
	}
	$temp_str = <CLASS_INFO>;
	my ($secondary_class_num) = $temp_str =~ m{secondary:(\d+)};
	defined $secondary_class_num or die 'can\'t parse classInfo';
	foreach(1..$secondary_class_num) {
		$temp_str = <CLASS_INFO>;
		my @temp_vec = split /\s+/,$temp_str;
		scalar @temp_vec == 2 or die 'format of classInfo is wrong!';
		defined $main_classes{$temp_vec[1]} or die 'don\'t have such main class';
		-e $temp_vec[0] or die 'don\'t have class file';
		my $temp_doc_num = int(`wc -l <${temp_vec[0]}`);
		$main_classes{$temp_vec[1]}->{child}->{$temp_vec[0]}->{doc_num} = $temp_doc_num;
		if($temp_doc_num > $doc_for_each_class) {
			$total_doc_num += $doc_for_each_class;
		} else {
			$total_doc_num += $temp_doc_num
		}
	}
	return {class_info=>\%main_classes,doc_num=>$total_doc_num};
}
sub getRandomVector{
	my $start = $_[0];
	my $end = $_[1];#< $end
	my $num = $_[2];
	my %randomhash;
	srand();
	while($num != 0) {
		my $temp = $start + int(rand($end - $start));
		if(!defined $randomhash{$temp}) {
			$num --;
			$randomhash{$temp} = 1;
		}
	}
	return sort{$a<=>$b} keys %randomhash;
}
